﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Registration : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["database"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        con.Open();
    }
    protected void BtnRegister(object sender, EventArgs e)
    {
        if (IsValid)
        {
            if (upasswordTxt.Text == upassword2.Text)
            {
                SqlCommand cmd = new SqlCommand("insert into userdata values('" + unameTxt.Text + "','" + uemailTxt.Text + "','" + upasswordTxt.Text + "','U')", con);
                cmd.ExecuteNonQuery();
                con.Close();
                Response.Redirect("~/shop1.aspx");
            }
            else
            {
                lblMsg.Text = "Passwords entered don't match";
                lblMsg.ForeColor = System.Drawing.Color.Red;
                upasswordTxt.Text = "";
                upassword2.Text = "";
            }
        }
    }
}