﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
    
public partial class Cart1 : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindCartProducts();
        }

    }

    private void BindCartProducts()
    {
        if (Request.Cookies["CartPID"] != null)
        {
            noItems.InnerText = "Shopping Cart";
            string CookieData = Request.Cookies["CartPID"].Value.Split('=')[1];
            string[] CookieDataArray = CookieData.Split(',');
            if (CookieDataArray.Length > 0)
            {
                DataTable dtBrands = new DataTable();
                Int64 CartTotal = 0;
                for (int i = 0; i < CookieDataArray.Length; i++)
                {
                    string PID = CookieDataArray[i].ToString().Split('-')[0];

                    String CS = ConfigurationManager.ConnectionStrings["database"].ConnectionString;
                    using (SqlConnection con = new SqlConnection(CS))
                    {
                        using (SqlCommand cmd = new SqlCommand("select * from tblProducts where PID=" + PID + "", con))
                        {
                            cmd.CommandType = CommandType.Text;
                            using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                            {
                                sda.Fill(dtBrands);
                            }
                        }
                        CartTotal += Convert.ToInt64(dtBrands.Rows[i]["PPrice"]);
                    }
                }
                rptrCartItem.DataSource = dtBrands;
                rptrCartItem.DataBind();
                divPricing.Visible = true;
                divFooter.Visible = true;
                spanCartTotal.InnerText = CartTotal.ToString();
            }
            else
            {
                noItems.InnerText = "Your Shopping Cart is Empty!";
                divPricing.Visible = false;
                divFooter.Visible = false;
            }
        }
        else
        {
            noItems.InnerText = "Your Shopping Cart is Empty!";
            divPricing.Visible = false;
            divFooter.Visible = false;
        }
    }

    protected void btnRemoveItem_Click(object sender, EventArgs e)
    {
        string CookiePID = Request.Cookies["CartPID"].Value.Split('=')[1];
        Button btn = (Button)(sender);
        string PIDrm = btn.CommandArgument;

        List<String> CookiePIDList = CookiePID.Split(',').Select(i => i.Trim()).Where(i => i != string.Empty).ToList();
        CookiePIDList.Remove(PIDrm);
        string CookiePIDUpdated = String.Join(",", CookiePIDList.ToArray());
        if (CookiePIDUpdated == "")
        {
            HttpCookie CartProducts = Request.Cookies["CartPID"];
            CartProducts.Values["CartPID"] = null;
            CartProducts.Expires = DateTime.Now.AddDays(-1);
            Response.Cookies.Add(CartProducts);

        }
        else
        {
            HttpCookie CartProducts = Request.Cookies["CartPID"];
            CartProducts.Values["CartPID"] = CookiePIDUpdated;
            CartProducts.Expires = DateTime.Now.AddDays(30);
            Response.Cookies.Add(CartProducts);

        }
        Response.Redirect("~/Cart.aspx");
    }
    protected void btnCheckout_Click(object sender, EventArgs e)
    {
        if (Request.Cookies["CEMAIL"] != null)
        {
            String CS = ConfigurationManager.ConnectionStrings["database"].ConnectionString;
            string CookieData = Request.Cookies["CartPID"].Value.Split('=')[1];
            string[] CookieDataArray = CookieData.Split(',');
            if (CookieDataArray.Length > 0)
            {
                using (SqlConnection con = new SqlConnection(CS))
                {
                    DataTable dtBrands = new DataTable();
                    Int64 CartTotal = 0;
                    for (int i = 0; i < CookieDataArray.Length; i++)
                    {
                        string pid = CookieDataArray[i].ToString().Split('-')[0];
                        using (SqlCommand cmd = new SqlCommand("select * from tblproducts where pid=" + pid + "", con))
                        {
                            cmd.CommandType = CommandType.Text;
                            using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                            {
                                sda.Fill(dtBrands);
                            }
                        }
                        CartTotal += Convert.ToInt64(dtBrands.Rows[i]["pprice"]);
                    }
                    string Email = Request.Cookies["CEMAIL"].Value;
                    con.Open();
                    SqlCommand cmd0 = new SqlCommand("insert into tblOrders values('" + Email + "','" + CartTotal + "','" + CookieData + "')", con);
                    cmd0.ExecuteNonQuery();
                }
                Response.Redirect("~/Checkout.aspx");
            }
        }
        else
        {
            Response.Redirect("~/Getin.aspx?rurl=cart");
        }
    }
}
