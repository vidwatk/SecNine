﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Uhome : System.Web.UI.Page
{
    private object lbluhome;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EMAIL"] != null)
        {
           // lbluhome.Text = "Login successful. Welcome " + Session["CUSRNME"].ToString() + "";
        }
        else
        {
            Response.Redirect("~/Login.aspx");
        }
    }
    protected void LogOut(object sender, EventArgs e)
    {
        Session["EMAIL"] = null;
        Response.Redirect("~/Index.aspx");
    }
}