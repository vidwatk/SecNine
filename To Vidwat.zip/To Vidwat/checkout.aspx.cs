﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Net.Mail;
using System.Net;

public partial class checkout : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.Cookies["CEMAIL"] != null)
        {
            BindPriceData();
        }
        else
        {
            Response.Redirect("~/Getin.aspx");
        }
    }
    private void BindPriceData()
    {
        if (Request.Cookies["CartPID"] != null)
        {
            string CookieData = Request.Cookies["CartPID"].Value.Split('=')[1];
            string[] CookieDataArray = CookieData.Split(',');
            if (CookieDataArray.Length > 0)
            {
                DataTable dtBrands = new DataTable();
                String loopPName = "";
                String fullPName = "";
                String mailMessage = "Thank you for your order. It will be dispatched shortly";
                for (int i = 0; i < CookieDataArray.Length; i++)
                {
                    string PID = CookieDataArray[i].ToString().Split('-')[0];

                    String CS = ConfigurationManager.ConnectionStrings["Database"].ConnectionString;
                    using (SqlConnection con = new SqlConnection(CS))
                    {
                        using (SqlCommand cmd = new SqlCommand("select * from tblproducts where pid=" + PID + "", con))
                        {
                            cmd.CommandType = CommandType.Text;
                            using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                            {
                                sda.Fill(dtBrands);
                            }
                        }
                        loopPName = Convert.ToString(dtBrands.Rows[i]["pname"]);
                        fullPName = fullPName + loopPName + "<br/>";
                    }
                }
                mailMessage = mailMessage + "</br>" + fullPName;
                // Code to send the mail
                String ToEmailAddress = Request.Cookies["CEMAIL"].Value;
                String EmailBody = mailMessage;
                MailMessage PassRecMail = new MailMessage("vidwatk@gmail.com", ToEmailAddress);
                PassRecMail.Body = EmailBody;
                PassRecMail.IsBodyHtml = true;
                PassRecMail.Subject = "Section18 | Order Confirmation";
                SmtpClient SMTP = new SmtpClient("SMTP.gmail.com", 587);
                SMTP.Credentials = new NetworkCredential()
                {
                    UserName = "armismarket@gmail.com",
                    Password = "armismarket1408"
                };
                SMTP.EnableSsl = true;
                SMTP.Send(PassRecMail);

              
                if (Request.Cookies["CartPID"] != null)
                {
                    Response.Cookies["CartPID"].Expires = DateTime.Now.AddDays(-1);
                }
            }
        }
        else
        {
            Response.Redirect("~/Shop1.aspx");
        }
    }
}