﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class AddProducts : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {

        }
    }
 protected void BtnAdd_Click(object sender, EventArgs e)
    {
        String CS = ConfigurationManager.ConnectionStrings["Database"].ConnectionString;
        using (SqlConnection con = new SqlConnection(CS))
        {
            Int64 pprice = Convert.ToInt64(txtprice.Text);
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into tblproducts values('" + txtname.Text + "', '" + pprice + "', '" + txtbrands.Text + "','" + txtcategory.Text + "', '" + ddlsize.SelectedItem.Value + "', '" + DropDownList1.SelectedItem.Value + "', '"+ txtdesc.Text + "' )", con);
            
            cmd.ExecuteNonQuery();

              if (FuImg1.HasFile)
            {
                string SavePath = Server.MapPath("~/Images/ProductImages/");
                if (!Directory.Exists(SavePath))
                {
                    Directory.CreateDirectory(SavePath);
                }
                string Extention = ".jpg";
                FuImg1.SaveAs(SavePath + "\\" + txtname.Text.ToString().Trim() + "mini" + Extention);
            }
            if (FuImg2.HasFile)
            {
                string SavePath = Server.MapPath("~/Images/ProductImages/");
                if (!Directory.Exists(SavePath))
                {
                    Directory.CreateDirectory(SavePath);
                }
                string Extention = ".jpg";
                FuImg2.SaveAs(SavePath + "\\" + txtname.Text.ToString().Trim() + "banner" + Extention);
            }
            if (FuImg3.HasFile)
            {
                string SavePath = Server.MapPath("~/Images/ProductImages/");
                if (!Directory.Exists(SavePath))
                {
                    Directory.CreateDirectory(SavePath);
                }
                string Extention = ".jpg";
                FuImg3.SaveAs(SavePath + "\\" + txtname.Text.ToString().Trim() + "ex" + Extention);
            }
        }

    }

}

