﻿using System;
using System.Web;
using System.Collections.Generic;
using System.Web.UI;
using System.Linq;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Getin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        {
            if (!IsPostBack)
            {
                if (Request.Cookies["CEMAIL"] != null && Request.Cookies["CPSWD"] != null)
                {
                    lblusrnme.Text = Request.Cookies["CEMAIL"].Value;
                    lblpswrd.Attributes["value"] = Request.Cookies["CPSWD"].Value;
                    CheckBox1.Checked = true;
                }
            }
        }
    }

    protected void BtnLogin(object sender, EventArgs e)
    {
        String CS = ConfigurationManager.ConnectionStrings["database"].ConnectionString;
        using (SqlConnection con = new SqlConnection(CS))
        {
            SqlCommand cmd = new SqlCommand("select * from userdata where EmailId='" + lblusrnme.Text + "' and Password='" + lblpswrd.Text + "'", con);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count != 0)
            {
                if (CheckBox1.Checked)
                {
                    Response.Cookies["CEMAIL"].Value = lblusrnme.Text;
                    Response.Cookies["CPSWD"].Value = lblpswrd.Text;

                    Response.Cookies["CEMAIL"].Expires = DateTime.Now.AddDays(15);
                    Response.Cookies["CPSWD"].Expires = DateTime.Now.AddDays(15);
                }
                else
                {
                    Response.Cookies["CEMAIL"].Value = lblusrnme.Text;
                    Response.Cookies["CPSWD"].Value = lblpswrd.Text;

                    Response.Cookies["CEMAIL"].Expires = DateTime.Now.AddDays(1);
                    Response.Cookies["CPSWD"].Expires = DateTime.Now.AddDays(1);
                }

                string LogType;
                LogType = dt.Rows[0][4].ToString().Trim();

                if (LogType == "U")
                {
                    Session["EMAIL"] = lblusrnme.Text;
                    if (Request.QueryString["rurl"] != null)
                    {
                        if (Request.QueryString["rurl"] == "cart")
                        {
                            Response.Redirect("~/Cart1.aspx");
                        }
                    }
                    else
                    {
                        Response.Redirect("~/Uhome.aspx");
                    }
                }
            }
            else
            {
                lblError.Text = "Incorrect Username or Password";
                lblError.ForeColor = System.Drawing.Color.IndianRed;
            }
        }
   }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {

    }
}
