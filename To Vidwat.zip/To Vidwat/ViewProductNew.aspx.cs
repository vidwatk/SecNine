﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ViewProductNew : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindProductRepeater();
        }
    }


    protected void BindProductRepeater()
    {
        Int64 pid = Convert.ToInt64(Request.QueryString["PID"]);
        //Int64 pid = 1;
        String CS = ConfigurationManager.ConnectionStrings["database"].ConnectionString;
        using (SqlConnection con = new SqlConnection(CS))
        {
            using (SqlCommand cmd = new SqlCommand("select * from tblproducts where pid=" + pid + "", con))
            {
                cmd.CommandType = CommandType.Text;
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    DataTable dtBrands = new DataTable();
                    sda.Fill(dtBrands);
                    rptrProducts.DataSource = dtBrands;
                    rptrProducts.DataBind();
                }
            }
        }
    }


    //protected void BindProductRepeater()
    //{
    //    Int64 pid = 1;
    //    SqlCommand command;
    //    SqlDataReader dataReader;
    //    String sql;
    //    sql = "select * from tblproducts where pid=" + pid + "";
    //    SqlConnection CS = new SqlConnection(ConfigurationManager.ConnectionStrings["database"].ConnectionString);
    //    command = new SqlCommand(sql, CS);
    //    CS.Open();
    //    dataReader = command.ExecuteReader();
    //    while (dataReader.Read())
    //    {
    //        pname1.text=dataReader.GetValue(1);
    //    }
    //    CS.Close();
    //    //Response.Write(Output);
    //    //dataReader.Close();
    //    //command.dispose();
    //    //conn.Close();
    //}



    protected void BtnAddClick(object sender, EventArgs e)
    {

        Int64 pid = Convert.ToInt64(Request.QueryString["pid"]);

        if (Request.Cookies["CartPID"] != null)
        {
            string CookiePID = Request.Cookies["CartPID"].Value.Split('=')[1];
            CookiePID = CookiePID + "," + pid;

            HttpCookie CartProducts = new HttpCookie("CartPID");
            CartProducts.Values["CartPID"] = pid.ToString();
            CartProducts.Expires = DateTime.Now.AddDays(30);
            Response.Cookies.Add(CartProducts);
        }
        else
        {
            HttpCookie CartProducts = new HttpCookie("CartPID");
            CartProducts.Values["CartPID"] = pid.ToString();
            CartProducts.Expires = DateTime.Now.AddDays(30);
            Response.Cookies.Add(CartProducts);
        }
    }
}