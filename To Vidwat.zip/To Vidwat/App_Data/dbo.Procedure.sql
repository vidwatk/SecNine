﻿CREATE PROCEDURE[dbo].[procProducts]
(
	
	@pname nvarchar(MAX),
	@pprice money,
	@pbrandID bigint,
	@pcategory bigint,
	@psize bigint,
	@pgender bigint,
	@pdescription nvarchar,
	@pfreedelivery bigint
)
AS
insert into tblproducts values(@pname, @pprice, @pbrandID, @pcategory, @psize, @pgender, @pdescription, @pfreedelivery)
select SCOPE_IDENTITY()
RETURN 0
